import 'home_screen.dart';
import 'package:flutter/material.dart';

const Color whiteColor=Colors.white;
const Color grayColor = Colors.grey;
const Color purpleColor = Colors.purple;
 const headingTextStyle = TextStyle(
   fontSize: 10,
   color: whiteColor,
   fontWeight: FontWeight.w900);